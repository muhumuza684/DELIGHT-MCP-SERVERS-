const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'files.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT UNIQUE NOT NULL,
    original_name TEXT,
    mime_type TEXT,
    size_bytes INTEGER,
    stored_path TEXT NOT NULL,
    kind TEXT NOT NULL,          -- upload | thumbnail | pdf
    parent_reference TEXT,       -- for thumbnails, links back to the original upload
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

module.exports = db;
