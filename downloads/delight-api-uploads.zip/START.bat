@echo off
if not exist "%USERPROFILE%\Postman\files" mkdir "%USERPROFILE%\Postman\files"
if exist "%~dp0sample.png" copy /Y "%~dp0sample.png" "%USERPROFILE%\Postman\files\sample.png" >nul
cd /d "%~dp0"
title DELIGHT API
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed yet.
  echo Opening the download page. Install it, then double-click START.bat again.
  start https://nodejs.org
  pause
  exit /b
)
if not exist node_modules (
  echo First start: setting things up. This takes a minute...
  call npm install --no-audit --no-fund
)
node start-helper.js
echo Your API is running. Leave this window open. Close it to stop.
node server.js
pause
