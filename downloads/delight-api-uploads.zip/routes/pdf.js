const express = require('express');
const path = require('path');
const fs = require('fs');
const PDFDocument = require('pdfkit');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const apiKeyAuth = require('../middleware/apiKeyAuth');
const { UPLOAD_DIR } = require('../utils/uploadConfig');

const router = express.Router();

// POST /pdf/generate - simple text/title -> PDF. Extend with a real template
// engine (e.g. handlebars -> html -> pdf) for invoices, certificates, etc.
router.post(
  '/generate',
  apiKeyAuth,
  express.json(),
  [
    body('title').isString().notEmpty(),
    body('body').isString().notEmpty(),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    const { title, body: content } = req.body;
    const outName = `pdf-${Date.now()}.pdf`;
    const outPath = path.join(UPLOAD_DIR, outName);

    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outPath);
    doc.pipe(stream);
    doc.fontSize(20).text(title, { underline: true });
    doc.moveDown();
    doc.fontSize(12).text(content);
    doc.end();

    stream.on('finish', () => {
      const stats = fs.statSync(outPath);
      const reference = 'file_' + uuidv4();

      db.prepare(`
        INSERT INTO files (reference, original_name, mime_type, size_bytes, stored_path, kind)
        VALUES (?, ?, 'application/pdf', ?, ?, 'pdf')
      `).run(reference, outName, stats.size, outPath);

      const record = db.prepare('SELECT * FROM files WHERE reference = ?').get(reference);
      res.status(201).json({
        reference: record.reference,
        mime_type: record.mime_type,
        size_bytes: record.size_bytes,
        download_url: `${req.protocol}://${req.get('host')}/files/${record.reference}/download`,
        created_at: record.created_at,
      });
    });

    stream.on('error', (err) => {
      res.status(500).json({ error: 'PDF generation failed', detail: err.message });
    });
  }
);

module.exports = router;
