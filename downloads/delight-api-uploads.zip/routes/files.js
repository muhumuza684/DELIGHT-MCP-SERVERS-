const express = require('express');
const path = require('path');
const fs = require('fs');
const sharp = require('sharp');
const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const apiKeyAuth = require('../middleware/apiKeyAuth');
const { upload, UPLOAD_DIR } = require('../utils/uploadConfig');

const router = express.Router();

function toResponse(record, req) {
  return {
    reference: record.reference,
    original_name: record.original_name,
    mime_type: record.mime_type,
    size_bytes: record.size_bytes,
    kind: record.kind,
    parent_reference: record.parent_reference,
    download_url: `${req.protocol}://${req.get('host')}/files/${record.reference}/download`,
    created_at: record.created_at,
  };
}

// POST /files/upload
router.post('/upload', apiKeyAuth, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file provided (expected multipart field "file")' });
  }

  const reference = 'file_' + uuidv4();
  db.prepare(`
    INSERT INTO files (reference, original_name, mime_type, size_bytes, stored_path, kind)
    VALUES (?, ?, ?, ?, ?, 'upload')
  `).run(reference, req.file.originalname, req.file.mimetype, req.file.size, req.file.path);

  const record = db.prepare('SELECT * FROM files WHERE reference = ?').get(reference);
  res.status(201).json(toResponse(record, req));
});

// POST /files/:reference/resize - creates a resized thumbnail from an uploaded image
router.post('/:reference/resize', apiKeyAuth, express.json(), async (req, res) => {
  const original = db.prepare('SELECT * FROM files WHERE reference = ?').get(req.params.reference);
  if (!original) return res.status(404).json({ error: 'File not found' });

  const width = parseInt(req.body.width, 10) || 200;
  const height = req.body.height ? parseInt(req.body.height, 10) : null;

  try {
    const outName = `resized-${Date.now()}.jpg`;
    const outPath = path.join(UPLOAD_DIR, outName);

    await sharp(original.stored_path)
      .resize(width, height, { fit: 'cover' })
      .jpeg({ quality: 80 })
      .toFile(outPath);

    const stats = fs.statSync(outPath);
    const reference = 'file_' + uuidv4();

    db.prepare(`
      INSERT INTO files (reference, original_name, mime_type, size_bytes, stored_path, kind, parent_reference)
      VALUES (?, ?, ?, ?, ?, 'thumbnail', ?)
    `).run(reference, outName, 'image/jpeg', stats.size, outPath, original.reference);

    const record = db.prepare('SELECT * FROM files WHERE reference = ?').get(reference);
    res.status(201).json(toResponse(record, req));
  } catch (err) {
    res.status(422).json({ error: 'Could not process image', detail: err.message });
  }
});

// GET /files/:reference/download
router.get('/:reference/download', apiKeyAuth, (req, res) => {
  const record = db.prepare('SELECT * FROM files WHERE reference = ?').get(req.params.reference);
  if (!record) return res.status(404).json({ error: 'File not found' });
  if (!fs.existsSync(record.stored_path)) return res.status(410).json({ error: 'File no longer on disk' });

  res.download(record.stored_path, record.original_name);
});

// GET /files - list metadata
router.get('/', apiKeyAuth, (req, res) => {
  const records = db.prepare('SELECT * FROM files ORDER BY created_at DESC LIMIT 100').all();
  res.json({ files: records.map((r) => toResponse(r, req)) });
});

module.exports = router;
