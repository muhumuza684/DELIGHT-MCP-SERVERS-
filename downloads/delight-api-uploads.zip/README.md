# File/Media API (Template #5 — Bryt Ma Tech UG)

Upload files, generate resized image thumbnails, and generate PDFs on demand —
with a metadata log so you can track and serve everything by reference ID.

Stack: Node.js, Express, SQLite, Multer (uploads), Sharp (image processing), PDFKit.

## Setup
```bash
npm install
cp .env.example .env    # set API_KEY, adjust MAX_UPLOAD_MB
node server.js
```

## Endpoints

| Method | Route | Auth | Description |
|---|---|---|---|
| GET | /health | No | Health check |
| POST | /files/upload | `x-api-key` | Upload a file (multipart, field name `file`) |
| POST | /files/:reference/resize | `x-api-key` | Create a resized thumbnail from an uploaded image |
| GET | /files/:reference/download | `x-api-key` | Download any file (original, thumbnail, or PDF) |
| GET | /files | `x-api-key` | List recent files |
| POST | /pdf/generate | `x-api-key` | Generate a simple PDF from title + body text |

## Customizing per client
- **Storage backend**: files currently save to local disk (`storage/uploads/`). For production or multi-server deployments, swap `utils/uploadConfig.js` to stream to S3, Cloudinary, or DigitalOcean Spaces instead — the DB schema (`stored_path`) can hold a cloud URL just as easily as a local path.
- **PDF templates**: `routes/pdf.js` currently does plain title+body text. For real documents (invoices, certificates, reports), swap in a template engine — build HTML with Handlebars/EJS and pipe it through Puppeteer, or lay it out directly with PDFKit's drawing API for pixel control.
- **Image transforms**: Sharp supports far more than resize — crop, watermark, format conversion (WebP, AVIF), rotation. Add routes as needed following the same pattern as `/resize`.
- **File size/type limits**: tune `MAX_UPLOAD_MB` in `.env`; add a `fileFilter` to `utils/uploadConfig.js` to restrict to specific MIME types per client.

## Testing
Import `postman_collection.json` into Postman (use form-data for the upload request), or:
```bash
curl -X POST http://localhost:4005/files/upload \
  -H "x-api-key: YOUR_KEY" -F "file=@/path/to/image.jpg"

curl -X POST http://localhost:4005/pdf/generate \
  -H "Content-Type: application/json" -H "x-api-key: YOUR_KEY" \
  -d '{"title":"Invoice #001","body":"Amount due: $500"}'
```
