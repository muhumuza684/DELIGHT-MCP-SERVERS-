# Auth API (Template #1 — Bryt Ma Tech UG)

Reusable JWT authentication API: signup, login, refresh tokens, protected routes, logout.
Stack: Node.js, Express, SQLite (better-sqlite3), bcrypt, JWT.

## Setup
```bash
npm install
cp .env.example .env   # edit JWT_ACCESS_SECRET before going live
node server.js
```
Server runs on `http://localhost:4001` by default.

## Endpoints

| Method | Route | Auth required | Description |
|---|---|---|---|
| GET | /health | No | Health check |
| POST | /auth/signup | No | Create account, returns tokens |
| POST | /auth/login | No | Login, returns tokens |
| POST | /auth/refresh | No | Exchange refresh token for new access token |
| POST | /auth/logout | No | Revoke a refresh token |
| GET | /auth/me | **Yes (Bearer token)** | Returns current user |

## Customizing per client
- **Branding/config**: edit `.env` (secrets, token expiry, port).
- **Add fields to user** (e.g. phone, role): edit `db.js` schema + `routes/auth.js` signup handler.
- **Swap SQLite for Postgres/MySQL**: only `db.js` needs to change — routes use `db.prepare(...)` style queries, keep the same interface or adapt to your ORM.
- **Add roles/permissions**: extend the JWT payload in `utils/tokens.js` and check `req.user` in downstream routes.
- **Password reset flow**: stub not included yet — add an `/auth/forgot-password` + `/auth/reset-password` pair reusing the refresh-token table pattern for reset tokens.

## Testing
Import `postman_collection.json` into Postman, or use curl — see examples below.

```bash
curl -X POST http://localhost:4001/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"SecurePass123","name":"Test User"}'
```

## Security notes before selling/deploying
- Always set a strong, random `JWT_ACCESS_SECRET` in production — never use the example value.
- Serve over HTTPS only.
- Consider adding email verification before allowing login (not included in this base template).
- `express-rate-limit` is already wired in `server.js` — tune `max`/`windowMs` per client plan.
