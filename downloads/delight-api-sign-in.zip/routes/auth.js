const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { signAccessToken, generateRefreshToken } = require('../utils/tokens');
const authenticate = require('../middleware/authenticate');

const router = express.Router();

function handleValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: 'Validation failed', details: errors.array() });
  }
  next();
}

// POST /auth/signup
router.post(
  '/signup',
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
    body('name').optional().isString().trim(),
  ],
  handleValidation,
  (req, res) => {
    const { email, password, name } = req.body;

    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const password_hash = bcrypt.hashSync(password, 10);
    const result = db
      .prepare('INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)')
      .run(email, password_hash, name || null);

    const user = { id: result.lastInsertRowid, email, name: name || null };
    const accessToken = signAccessToken(user);
    const { token: refreshToken, expiresAt } = generateRefreshToken();

    db.prepare('INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?, ?, ?)').run(
      user.id,
      refreshToken,
      expiresAt
    );

    res.status(201).json({ user, accessToken, refreshToken });
  }
);

// POST /auth/login
router.post(
  '/login',
  [body('email').isEmail(), body('password').notEmpty()],
  handleValidation,
  (req, res) => {
    const { email, password } = req.body;
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

    if (!row || !bcrypt.compareSync(password, row.password_hash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const user = { id: row.id, email: row.email, name: row.name };
    const accessToken = signAccessToken(user);
    const { token: refreshToken, expiresAt } = generateRefreshToken();

    db.prepare('INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?, ?, ?)').run(
      user.id,
      refreshToken,
      expiresAt
    );

    res.json({ user, accessToken, refreshToken });
  }
);

// POST /auth/refresh
router.post('/refresh', [body('refreshToken').notEmpty()], handleValidation, (req, res) => {
  const { refreshToken } = req.body;
  const row = db.prepare('SELECT * FROM refresh_tokens WHERE token = ?').get(refreshToken);

  if (!row) {
    return res.status(401).json({ error: 'Invalid refresh token' });
  }
  if (new Date(row.expires_at) < new Date()) {
    db.prepare('DELETE FROM refresh_tokens WHERE id = ?').run(row.id);
    return res.status(401).json({ error: 'Refresh token expired' });
  }

  const user = db.prepare('SELECT id, email, name FROM users WHERE id = ?').get(row.user_id);
  const accessToken = signAccessToken(user);

  res.json({ accessToken });
});

// POST /auth/logout
router.post('/logout', [body('refreshToken').notEmpty()], handleValidation, (req, res) => {
  const { refreshToken } = req.body;
  db.prepare('DELETE FROM refresh_tokens WHERE token = ?').run(refreshToken);
  res.json({ message: 'Logged out' });
});

// GET /auth/me (protected)
router.get('/me', authenticate, (req, res) => {
  const user = db.prepare('SELECT id, email, name, created_at FROM users WHERE id = ?').get(req.user.id);
  res.json({ user });
});

module.exports = router;
