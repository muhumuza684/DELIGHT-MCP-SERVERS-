const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'payments.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT UNIQUE NOT NULL,
    idempotency_key TEXT UNIQUE,
    provider TEXT NOT NULL,            -- stripe | mtn | airtel
    amount INTEGER NOT NULL,           -- smallest currency unit (cents, or UGX as whole units)
    currency TEXT NOT NULL,
    phone TEXT,                        -- for mobile money
    customer_email TEXT,               -- for card payments
    status TEXT NOT NULL DEFAULT 'pending', -- pending | success | failed
    provider_ref TEXT,                 -- provider's own transaction id
    metadata TEXT,                     -- JSON string for any extra client data
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

module.exports = db;
