const MOCK_MODE = process.env.MOCK_MODE === 'true' || !process.env.STRIPE_SECRET_KEY;

let stripe = null;
if (!MOCK_MODE) {
  stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
}

/**
 * Initiates a card charge. In MOCK_MODE, simulates Stripe's response so the
 * whole flow (ledger, idempotency, webhook confirmation) can be tested for
 * free without a real Stripe account. Set STRIPE_SECRET_KEY in .env to go live.
 */
async function charge({ amount, currency, customerEmail, metadata }) {
  if (MOCK_MODE) {
    return {
      provider_ref: 'pi_mock_' + Date.now(),
      status: 'pending', // real Stripe charges confirm asynchronously via webhook
      raw: { mock: true, amount, currency, customerEmail },
    };
  }

  const intent = await stripe.paymentIntents.create({
    amount,
    currency,
    receipt_email: customerEmail,
    metadata,
  });

  return {
    provider_ref: intent.id,
    status: intent.status === 'succeeded' ? 'success' : 'pending',
    raw: intent,
  };
}

/**
 * Verifies and parses a Stripe webhook payload. In MOCK_MODE, skips signature
 * verification (there is no real Stripe signature to check).
 */
function parseWebhookEvent(rawBody, signature) {
  if (MOCK_MODE) {
    return JSON.parse(rawBody);
  }
  return stripe.webhooks.constructEvent(rawBody, signature, process.env.STRIPE_WEBHOOK_SECRET);
}

module.exports = { charge, parseWebhookEvent, MOCK_MODE };
