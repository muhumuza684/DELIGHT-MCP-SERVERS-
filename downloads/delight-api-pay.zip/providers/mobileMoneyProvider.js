/**
 * Mobile Money providers (MTN MoMo, Airtel Money) work asynchronously in real life:
 * 1. You request a charge -> provider sends a USSD/STK prompt to the customer's phone.
 * 2. Customer approves on their phone.
 * 3. Provider calls YOUR webhook some seconds/minutes later with the result.
 *
 * This template mocks that exact flow so you can build and test the full
 * async ledger + webhook pattern for free. To go live, replace the body of
 * requestPayment() with a real call to the MTN MoMo Collections API or the
 * Airtel Money Open API (both require merchant registration + sandbox credentials
 * from the provider before they'll accept requests).
 */

const MOCK_MODE = process.env.MOBILE_MONEY_MOCK !== 'false';

async function requestPayment({ provider, amount, currency, phone }) {
  if (MOCK_MODE) {
    // Simulates the provider accepting the request and prompting the customer.
    // In a real integration this call returns immediately with a reference,
    // and the actual success/failure arrives later via webhook.
    return {
      provider_ref: `${provider}_mock_${Date.now()}`,
      status: 'pending',
      raw: { mock: true, provider, amount, currency, phone },
    };
  }

  // --- Real integration goes here, e.g.: ---
  // const resp = await axios.post('https://sandbox.momodeveloper.mtn.com/collection/v1_0/requesttopay', {...});
  // return { provider_ref: resp.data.referenceId, status: 'pending', raw: resp.data };
  throw new Error('Live mobile money integration not configured. Set MOBILE_MONEY_MOCK=true for testing.');
}

module.exports = { requestPayment, MOCK_MODE };
