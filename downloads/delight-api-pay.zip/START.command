#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed yet."
  echo "Opening the download page. Install it, then open START.command again."
  open https://nodejs.org
  read -p "Press Enter to close"
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "First start: setting things up. This takes a minute..."
  npm install --no-audit --no-fund
fi
node start-helper.js
echo "Your API is running. Leave this window open. Close it to stop."
node server.js
