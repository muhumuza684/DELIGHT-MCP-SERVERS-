const fs=require('fs'),crypto=require('crypto');
if(!fs.existsSync('.env')){
  const t=fs.readFileSync('.env.example','utf8').replace(/^([A-Z_]+)=change_this\S*/gm,(m,k)=>k+'='+crypto.randomBytes(16).toString('hex'));
  fs.writeFileSync('.env',t);
  console.log('\nMade your settings file (.env) with fresh secret keys.');
}
const e=fs.readFileSync('.env','utf8'),env={};
e.split(/\r?\n/).forEach(l=>{const m=l.match(/^([A-Z_]+)=(.*)$/);if(m)env[m[1]]=m[2]});
const port=env.PORT||'4000';
// put this folder's real keys into the Postman collection, so every request works on the first click
try{
  const f='postman_collection.json';
  if(fs.existsSync(f)){
    const c=JSON.parse(fs.readFileSync(f,'utf8')),map={apiKey:'API_KEY',adminSecret:'ADMIN_SECRET',merchantKey:'MERCHANT_API_KEY'};
    let changed=false;
    (c.variable||[]).forEach(v=>{
      if(map[v.key]&&env[map[v.key]]&&v.value!==env[map[v.key]]){v.value=env[map[v.key]];changed=true}
      if(v.key==='jwtToken'&&env.JWT_SECRET){try{v.value=require('jsonwebtoken').sign({sub:1,email:'test@example.com'},env.JWT_SECRET,{expiresIn:'30d'});changed=true}catch(x){}}
    });
    if(changed){fs.writeFileSync(f,JSON.stringify(c,null,2));console.log('Postman file updated with your keys.')}
  }
}catch(x){}
console.log('\nYour keys (also saved in the .env file):');
e.split(/\r?\n/).filter(l=>/^[A-Z_]*(KEY|SECRET)[A-Z_]*=/.test(l)).forEach(l=>console.log('  '+l));
console.log('\nCheck page: http://localhost:'+port+'/health\n');
