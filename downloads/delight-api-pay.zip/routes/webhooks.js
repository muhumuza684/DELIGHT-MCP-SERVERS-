const express = require('express');
const db = require('../db');
const stripeProvider = require('../providers/stripeProvider');

const router = express.Router();

function updateStatusByProviderRef(providerRef, status) {
  const result = db
    .prepare('UPDATE transactions SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE provider_ref = ?')
    .run(status, providerRef);
  return result.changes > 0;
}

// POST /webhooks/stripe - Stripe calls this when a payment intent's status changes
router.post('/stripe', express.raw({ type: 'application/json' }), (req, res) => {
  let event;
  try {
    const signature = req.headers['stripe-signature'];
    event = stripeProvider.parseWebhookEvent(req.body, signature);
  } catch (err) {
    return res.status(400).json({ error: 'Invalid webhook signature', detail: err.message });
  }

  if (event.type === 'payment_intent.succeeded') {
    updateStatusByProviderRef(event.data.object.id, 'success');
  } else if (event.type === 'payment_intent.payment_failed') {
    updateStatusByProviderRef(event.data.object.id, 'failed');
  }

  res.json({ received: true });
});

// POST /webhooks/mobile-money - MTN/Airtel would call this when the customer
// approves or rejects the USSD/STK prompt on their phone.
router.post('/mobile-money', express.json(), (req, res) => {
  const { provider_ref, status } = req.body;
  if (!provider_ref || !['success', 'failed'].includes(status)) {
    return res.status(400).json({ error: 'provider_ref and a valid status (success|failed) are required' });
  }

  const updated = updateStatusByProviderRef(provider_ref, status);
  if (!updated) {
    return res.status(404).json({ error: 'No transaction found for that provider_ref' });
  }

  res.json({ received: true });
});

// POST /webhooks/simulate - TEST-ONLY helper to manually resolve a mock
// transaction, since there is no real provider calling back in mock mode.
// Remove this route before going live with real providers.
router.post('/simulate', express.json(), (req, res) => {
  const { provider_ref, status } = req.body;
  if (!provider_ref || !['success', 'failed'].includes(status)) {
    return res.status(400).json({ error: 'provider_ref and a valid status (success|failed) are required' });
  }
  const updated = updateStatusByProviderRef(provider_ref, status);
  if (!updated) {
    return res.status(404).json({ error: 'No transaction found for that provider_ref' });
  }
  res.json({ message: `Transaction marked as ${status} (test simulation)` });
});

module.exports = router;
