const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const merchantAuth = require('../middleware/merchantAuth');
const stripeProvider = require('../providers/stripeProvider');
const mobileMoneyProvider = require('../providers/mobileMoneyProvider');

const router = express.Router();

// POST /payments/charge
router.post(
  '/charge',
  merchantAuth,
  [
    body('provider').isIn(['stripe', 'mtn', 'airtel']).withMessage('provider must be stripe, mtn, or airtel'),
    body('amount').isInt({ min: 1 }).withMessage('amount must be a positive integer (smallest currency unit)'),
    body('currency').isString().isLength({ min: 3, max: 3 }).withMessage('currency must be a 3-letter code'),
    body('phone').if(body('provider').isIn(['mtn', 'airtel'])).notEmpty().withMessage('phone required for mobile money'),
    body('customer_email').if(body('provider').equals('stripe')).optional().isEmail(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    const idempotencyKey = req.headers['idempotency-key'];

    // Idempotency: if this key was already used, return the original result
    // instead of creating a duplicate charge.
    if (idempotencyKey) {
      const existing = db.prepare('SELECT * FROM transactions WHERE idempotency_key = ?').get(idempotencyKey);
      if (existing) {
        return res.status(200).json(toResponse(existing, { replayed: true }));
      }
    }

    const { provider, amount, currency, phone, customer_email, metadata } = req.body;
    const reference = 'txn_' + uuidv4();

    try {
      let result;
      if (provider === 'stripe') {
        result = await stripeProvider.charge({ amount, currency, customerEmail: customer_email, metadata });
      } else {
        result = await mobileMoneyProvider.requestPayment({ provider, amount, currency, phone });
      }

      const insert = db.prepare(`
        INSERT INTO transactions
          (reference, idempotency_key, provider, amount, currency, phone, customer_email, status, provider_ref, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      insert.run(
        reference,
        idempotencyKey || null,
        provider,
        amount,
        currency.toUpperCase(),
        phone || null,
        customer_email || null,
        result.status,
        result.provider_ref,
        metadata ? JSON.stringify(metadata) : null
      );

      const record = db.prepare('SELECT * FROM transactions WHERE reference = ?').get(reference);
      res.status(201).json(toResponse(record));
    } catch (err) {
      console.error(err);
      res.status(502).json({ error: 'Payment provider error', detail: err.message });
    }
  }
);

// GET /payments/:reference
router.get('/:reference', merchantAuth, (req, res) => {
  const record = db.prepare('SELECT * FROM transactions WHERE reference = ?').get(req.params.reference);
  if (!record) {
    return res.status(404).json({ error: 'Transaction not found' });
  }
  res.json(toResponse(record));
});

// GET /payments (list, for reconciliation)
router.get('/', merchantAuth, (req, res) => {
  const records = db.prepare('SELECT * FROM transactions ORDER BY created_at DESC LIMIT 100').all();
  res.json({ transactions: records.map((r) => toResponse(r)) });
});

function toResponse(record, extra = {}) {
  return {
    reference: record.reference,
    provider: record.provider,
    amount: record.amount,
    currency: record.currency,
    status: record.status,
    provider_ref: record.provider_ref,
    created_at: record.created_at,
    updated_at: record.updated_at,
    ...extra,
  };
}

module.exports = router;
