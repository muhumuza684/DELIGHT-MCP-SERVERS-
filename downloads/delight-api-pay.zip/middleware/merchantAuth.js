function merchantAuth(req, res, next) {
  const key = req.headers['x-api-key'];
  if (!key || key !== process.env.MERCHANT_API_KEY) {
    return res.status(401).json({ error: 'Invalid or missing x-api-key' });
  }
  next();
}

module.exports = merchantAuth;
