require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const paymentsRoutes = require('./routes/payments');
const webhookRoutes = require('./routes/webhooks');
const { MOCK_MODE: STRIPE_MOCK } = require('./providers/stripeProvider');
const { MOCK_MODE: MOMO_MOCK } = require('./providers/mobileMoneyProvider');

const app = express();
const PORT = process.env.PORT || 4003;

app.use(helmet());
app.use(cors());

// Webhooks must be mounted BEFORE express.json() for the Stripe route,
// since Stripe signature verification needs the raw request body.
app.use('/webhooks', webhookRoutes);

app.use(express.json());

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300 });
app.use(limiter);

app.get('/health', (req, res) =>
  res.json({ status: 'ok', service: 'payments-api', stripeMock: STRIPE_MOCK, mobileMoneyMock: MOMO_MOCK })
);

app.use('/payments', paymentsRoutes);

app.use((req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => console.log(`Payments API running on port ${PORT}`));
