# Payments & Mobile Money API (Template #3 — Bryt Ma Tech UG)

Unified payments API supporting card payments (Stripe) and mobile money
(MTN/Airtel-style) behind one interface, with a transaction ledger,
idempotency protection (no double-charges), and webhook handling for
async confirmation.

Stack: Node.js, Express, SQLite, Stripe SDK.

## Why this design
Mobile money is inherently async in real life: you request a charge, the
customer approves a USSD/STK prompt on their phone, and the result arrives
seconds or minutes later via a webhook. Card payments can also be async
(3D Secure, bank review). This template treats **every** payment as
pending-until-confirmed and uses webhooks as the single source of truth for
final status — this is the correct pattern for both provider types.

## Setup
```bash
npm install
cp .env.example .env    # set MERCHANT_API_KEY; add real Stripe keys when ready
node server.js
```

## Mock mode (default, free to test)
- `MOCK_MODE=true` (or no `STRIPE_SECRET_KEY`) → Stripe calls are simulated.
- `MOBILE_MONEY_MOCK=true` (default) → MTN/Airtel calls are simulated.
- Use `POST /webhooks/simulate` to manually resolve a mock transaction to
  `success` or `failed` — this stands in for the real provider's callback
  during testing. **Remove this route before going live.**

## Endpoints

| Method | Route | Auth | Description |
|---|---|---|---|
| GET | /health | No | Health check, shows mock status |
| POST | /payments/charge | `x-api-key` | Initiate a charge (stripe/mtn/airtel) |
| GET | /payments/:reference | `x-api-key` | Check one transaction's status |
| GET | /payments | `x-api-key` | List recent transactions (reconciliation) |
| POST | /webhooks/stripe | Stripe signature | Stripe's async status callback |
| POST | /webhooks/mobile-money | Provider-specific | MTN/Airtel's async status callback |
| POST | /webhooks/simulate | None (test-only) | Manually resolve a mock transaction |

## Idempotency
Send an `Idempotency-Key` header with any charge request. If the same key is
sent again (e.g. a client's retry after a network timeout), the API returns
the original transaction instead of creating a second charge. Always
generate a fresh key per *logical* payment attempt, and reuse it only on retry.

## Going live — what to change per client
- **Stripe**: set `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET`, set `MOCK_MODE=false`. Register the real webhook URL in the Stripe dashboard.
- **MTN MoMo / Airtel Money**: both require merchant registration and sandbox/production credentials directly from the provider. Replace the body of `requestPayment()` in `providers/mobileMoneyProvider.js` with the real API call, set `MOBILE_MONEY_MOCK=false`, and register your webhook URL with the provider.
- **Currency**: amounts are stored in the smallest unit (cents for USD, whole units for UGX — confirm per provider's convention).
- **Remove `/webhooks/simulate`** before deployment — it's a test convenience only.

## Testing
Import `postman_collection.json` into Postman, or:
```bash
curl -X POST http://localhost:4003/payments/charge \
  -H "Content-Type: application/json" -H "x-api-key: YOUR_MERCHANT_KEY" \
  -H "Idempotency-Key: unique-attempt-id" \
  -d '{"provider":"mtn","amount":15000,"currency":"ugx","phone":"+256700000000"}'
```
